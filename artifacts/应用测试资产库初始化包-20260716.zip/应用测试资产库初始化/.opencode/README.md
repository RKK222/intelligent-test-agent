# 应用专属 OpenCode 配置架子

这里仅维护当前应用自己的测试 Agent、workagent、Skill、规约和模板，不复制公共 Git 的通用测试能力。

## 目录示例

```text
.opencode/
├── agents/
│   ├── application-test-design.md
│   ├── application-test-design-workagent.md
│   ├── application-test-execution.md
│   └── application-test-execution-workagent.md
└── skills/
    └── application-testing/
        ├── SKILL.md
        ├── rules/
        │   ├── 接口测试设计应用规约.md
        │   ├── UI测试设计应用规约.md
        │   ├── 异步任务测试设计应用规约.md
        │   ├── 批量任务测试设计应用规约.md
        │   ├── 其他测试设计应用规约.md
        │   └── 测试执行应用规约.md
        └── templates/
            ├── 测试设计文档模板.md
            ├── 测试案例模板.md
            └── 测试执行记录模板.md
```

## 怎么改

- 将 Agent 文件中的【待填写：应用名称】替换为真实应用名，并补充当前应用特有的职责和边界。
- `application-test-design.md` 与 `application-test-execution.md` 是用户可选择的主 Agent。
- `*-workagent.md` 是隐藏子 Agent，供主 Agent 拆分应用专属子任务。
- `SKILL.md` 负责选择应用规约和模板；`rules/` 只写应用差异，通用方法继续使用公共 Git。
- 新增 Skill 时复制 `application-testing/` 的结构，并保持目录名和 frontmatter `name` 一致。

不要提交 `.opencode/node_modules/`、本机生成的 package 文件、密钥或真实环境凭据。
