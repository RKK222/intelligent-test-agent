# 应用专属 OpenCode 配置模板

这里仅维护当前应用自己的测试 Agent、Skill、规约和模板，不复制公共 Git 的通用测试能力。

## 目录示例

```text
.opencode/
├── agents/
│   └── application-testing-template.md
└── skills/
    └── application-testing-template/
        ├── SKILL.md
        ├── rules/
        │   └── README.md
        └── templates/
            └── README.md
```

## 怎么改

- 复制并重命名 Agent 和 Skill 模板，将全部【待填写】替换为真实应用内容。
- `SKILL.md` 负责选择应用规约和输出模板；`rules/` 只写应用差异，通用方法继续使用公共 Git。
- Agent 文件名、Skill 目录名和 frontmatter `name` 应使用小写字母、数字和短横线。

不要提交 `.opencode/node_modules/`、本机生成的 package 文件、密钥或真实环境凭据。
