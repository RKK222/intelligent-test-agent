---
name: application-testing-template
description: 【待填写：应用名称】应用测试 Skill 模板
compatibility: opencode
metadata:
  scope: workspace
  source: application-test-assets
---

# 【待填写：应用名称】应用测试 Skill

## 适用场景

- 【待填写：列出需要加载当前应用测试知识的任务】

## 使用流程

1. 读取 `docs/应用架构/测试概述_模板.md` 完善后的应用测试概述。
2. 按任务需要读取 `rules/` 中的应用专属规约，不复制公共规约。
3. 根据产物类型选择 `templates/` 中的模板。
4. 输出事实依据、覆盖范围、执行状态、风险和待确认项。

## 资源

- `rules/`：放应用专属测试规约。
- `templates/`：放应用专属输出模板。
