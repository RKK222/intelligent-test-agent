---
name: application-testing
description: 加载当前应用专属的测试规则、知识和输出模板
compatibility: opencode
metadata:
  scope: workspace
  source: application-test-assets
---

# 应用测试

## 适用场景

当任务涉及【待填写：应用名称】的测试分析、测试设计、测试执行、测试数据、证据或稳定测试资产维护时使用本 Skill。

## 使用流程

1. 读取 `docs/应用架构/测试概述.md`，确认应用边界、测试环境与通用约束。
2. 根据测试对象只加载 `rules/` 下对应的应用规约，不一次性加载无关文件。
3. 复用公共 Git 已提供的通用测试 Agent、workagent 和 Skill；本 Skill 只补充应用差异。
4. 根据产物类型选择 `templates/` 下的模板，并将稳定结果维护到 `docs/**`。
5. 输出事实依据、覆盖范围、执行状态、风险和待确认项。

## 资源路由

- 接口：`rules/接口测试设计应用规约.md`
- UI：`rules/UI测试设计应用规约.md`
- 异步任务：`rules/异步任务测试设计应用规约.md`
- 批量任务：`rules/批量任务测试设计应用规约.md`
- 其它对象：`rules/其他测试设计应用规约.md`
- 测试执行：`rules/测试执行应用规约.md`
- 输出格式：`templates/`

## 边界

- 不把公共规约复制到本应用 Skill。
- 不读取或输出生产密钥、真实客户数据和无关个人信息。
- 无法确认的应用规则必须标记为“待确认”。
