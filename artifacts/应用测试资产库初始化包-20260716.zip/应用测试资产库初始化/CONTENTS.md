# 包内容清单

本包只包含应用 Git 的测试资产初始化内容：

- 4 个应用专属 Agent/workagent 定义。
- 1 个应用测试 Skill，含 6 份应用规约和 3 份输出模板。
- 6 份稳定测试资产文档模板，以及 1 份 docs 目录与命名示例。
- 1 份 `.opencode` 目录与扩展说明。
- 1 份归档规则说明。
- 初始化说明和安全的 `.gitignore`。

公共 Git 的 Agent、workagent、Skill、公共规约和 OpenCode 公共配置均未包含。
