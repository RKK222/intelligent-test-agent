# 包内容清单

本包只包含应用 Git 的测试资产初始化内容：

- 1 份应用测试 Agent 模板。
- 1 份应用测试 Skill 模板，含规约和输出模板的 README 架子。
- 6 份稳定测试资产文档模板，以及 1 份 docs 目录与命名示例。
- 1 份 `.opencode` 目录与扩展说明。
- 1 份归档规则说明。
- 初始化说明和安全的 `.gitignore`。

公共 Git 的 Agent、Skill、公共规约和 OpenCode 公共配置均未包含。
